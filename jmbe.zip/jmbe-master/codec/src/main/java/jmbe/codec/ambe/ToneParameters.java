/*
 * ******************************************************************************
 * Copyright (C) 2015-2019 Dennis Sheirer
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 * *****************************************************************************
 */

package jmbe.codec.ambe;

/**
 * AMBE tone frame parameters
 */
class ToneParameters
{
    private Tone mTone;
    private int mAmplitude;

    /**
     * Constructs an instance
     * @param tone enumeration entry
     * @param amplitude of the tone
     */
    public ToneParameters(Tone tone, int amplitude)
    {
        mTone = tone;
        mAmplitude = amplitude;
    }

    /**
     * Tone for this segment
     */
    public Tone getTone()
    {
        return mTone;
    }

    /**
     * Amplitude of the tone
     */
    public int getAmplitude()
    {
        return mAmplitude;
    }

    /**
     * Indicates if the tone is valid (ie not the INVALID enumeration entry)
     */
    public boolean isValidTone()
    {
        return getTone() != Tone.INVALID;
    }
}
